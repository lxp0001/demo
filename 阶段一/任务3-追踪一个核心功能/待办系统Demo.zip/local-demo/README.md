# 任务2本地完整版

这是一个不依赖第三方包的透明待办系统，用来观察真实的前端、API、后端和 JSON 数据文件。

## 运行

需要 Node.js 18 或更高版本。在本目录执行 node server.mjs。

浏览器访问 http://localhost:3102。

## 学生观察路径

1. 打开浏览器开发者工具的 Network 面板。
2. 新建一条任务，找到 POST /api/tasks。
3. 查看请求体、响应体和状态码。
4. 打开 server.mjs，找到处理 POST 请求的代码。
5. 打开 data/tasks.json，确认新任务已写入。
6. 刷新页面，确认前端通过 GET /api/tasks 重新读取数据。

## 文件与系统模块

| 文件 | 对应模块 |
| --- | --- |
| public/index.html | 前端界面与请求代码 |
| server.mjs | API 与后端业务处理 |
| data/tasks.json | 简化的数据存储 |
