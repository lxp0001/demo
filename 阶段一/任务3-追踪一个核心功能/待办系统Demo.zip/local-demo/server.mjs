import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const dataFile=path.join(root,'data','tasks.json');
const publicFile=path.join(root,'public','index.html');

async function readTasks(){return JSON.parse(await fs.readFile(dataFile,'utf8'));}
async function writeTasks(tasks){await fs.writeFile(dataFile,JSON.stringify(tasks,null,2));}
function json(res,status,body){res.writeHead(status,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(body));}

const server=http.createServer(async(req,res)=>{
  if(req.method==='GET'&&req.url==='/'){res.writeHead(200,{'content-type':'text/html; charset=utf-8'});res.end(await fs.readFile(publicFile));return;}
  if(req.method==='GET'&&req.url==='/api/tasks'){json(res,200,await readTasks());return;}
  if(req.method==='POST'&&req.url==='/api/tasks'){
    let raw='';for await(const chunk of req)raw+=chunk;
    const {title=''}=JSON.parse(raw||'{}');
    if(!title.trim()){json(res,400,{error:'任务标题不能为空'});return;}
    const tasks=await readTasks();const task={id:Date.now(),title:title.trim(),completed:false};
    tasks.unshift(task);await writeTasks(tasks);json(res,201,task);return;
  }
  const match=req.url.match(/^\/api\/tasks\/(\d+)$/);
  if(req.method==='PATCH'&&match){
    let raw='';for await(const chunk of req)raw+=chunk;
    const update=JSON.parse(raw||'{}');const tasks=await readTasks();
    const task=tasks.find(x=>x.id===Number(match[1]));
    if(!task){json(res,404,{error:'任务不存在'});return;}
    task.completed=Boolean(update.completed);await writeTasks(tasks);json(res,200,task);return;
  }
  if(req.method==='DELETE'&&match){
    const tasks=await readTasks();await writeTasks(tasks.filter(x=>x.id!==Number(match[1])));
    json(res,200,{ok:true});return;
  }
  json(res,404,{error:'接口不存在'});
});

const port=Number(process.env.PORT||3102);
server.listen(port,()=>console.log(`任务2 Demo：http://localhost:${port}`));
